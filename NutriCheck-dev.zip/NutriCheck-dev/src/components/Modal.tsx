export const Modal = () => {
  return <div>Invalid Credentials</div>;
};
