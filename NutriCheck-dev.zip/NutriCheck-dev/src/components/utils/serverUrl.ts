export const REACT_APP_BASE_URL = process.env.REACT_APP_BASE_URL;
